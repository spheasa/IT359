Information about this folder
-----------------------------

This folder contains old wrappers which are not being installed. These wrappers are stored pending of being fixed.
