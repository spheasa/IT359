About the authors
==================

Lead developers
---------------

This software is a personal project leaded by Yaiza Rubio ([@yrubiosec](https://twitter.com/yrubiosec)) and Félix Brezo ([@febrezo](https://twitter.com/febrezo)), both of whom conform the [i3visio](http://i3visio.com) team.

Contributors
------------

* Eva Suárez ([@EvaSuarez22](https://twitter.com/EvaSuarez22))
* Lucas Sánchez
* Fran J. Gómez ([@ffranz](https://twitter.com/ffranz))
* Abilio Almeida  ([@aabilio](https://github.com/aabilio))
* Bruno Halopeau ([@BrHa11](https://github.com/BrHa11))
