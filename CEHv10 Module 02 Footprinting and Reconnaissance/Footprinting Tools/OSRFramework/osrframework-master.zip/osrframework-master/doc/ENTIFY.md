Using entify.py
===============

TODO.
