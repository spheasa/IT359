Using the Alias Generator Tool
==============================

TODO.
