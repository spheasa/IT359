Using mailfy.py
===============

TODO.
