Using searchfy.py
=================

TODO.
