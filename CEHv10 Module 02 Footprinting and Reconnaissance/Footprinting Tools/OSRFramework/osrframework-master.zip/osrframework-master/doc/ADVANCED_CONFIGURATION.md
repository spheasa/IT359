Configuring OSRFramework
========================

TODO.
