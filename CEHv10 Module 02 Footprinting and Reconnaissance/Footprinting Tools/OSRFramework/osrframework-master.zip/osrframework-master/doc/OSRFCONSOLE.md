Introduction to OSRFConsole
===========================

TODO.
